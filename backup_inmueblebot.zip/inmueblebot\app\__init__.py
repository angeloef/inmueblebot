"""InmuebleBot application package init."""
