"""
Genera las tablas de la base de datos.
Útil para desarrollo sin migraciones de Alembic.
"""
import asyncio
from sqlalchemy.ext.asyncio import create_async_engine
from app.db.base import Base
from app.db.models import User, Property, Conversation, Message, Appointment
from app.core.config import get_settings


async def create_tables():
    """Crea todas las tablas en la base de datos."""
    settings = get_settings()
    
    engine = create_async_engine(settings.DATABASE_URL, echo=True)
    
    async with engine.begin() as conn:
        # Drop all tables (dev only!)
        # await conn.run_sync(Base.metadata.drop_all)
        
        # Create all tables
        await conn.run_sync(Base.metadata.create_all)
    
    await engine.dispose()
    print("✅ Tablas creadas exitosamente!")


if __name__ == "__main__":
    asyncio.run(create_tables())